The commands are too long and are breaking into multiple lines using ///
As a result: Not working if directly copy into the stata command window.

Copy and paste into the do-file editor and execute from there.
